//
//  Created on ___DATE___.
// ___VARIABLE_name___.swift - Very brief description
//


import Foundation
import Combine

// Mark: - Input Provider
protocol ___VARIABLE_name___ProviderInputProtocol: BaseProviderInputProtocol {
    
}

final class ___VARIABLE_name___Provider: BaseProvider {

    // MARK: - VIP Dependences
    weak var interactor: ___VARIABLE_name___ProviderOutputProtocol? {
        super.baseInteractor as? ___VARIABLE_name___ProviderOutputProtocol
    }
    
    let networkService: NetworkServiceProtocol = NetworkService()
    var cancellable: Set<AnyCancellable> = []
    
}

// Mark: - extension -> Input Provider
extension ___VARIABLE_name___Provider: ___VARIABLE_name___ProviderInputProtocol {
    
}


