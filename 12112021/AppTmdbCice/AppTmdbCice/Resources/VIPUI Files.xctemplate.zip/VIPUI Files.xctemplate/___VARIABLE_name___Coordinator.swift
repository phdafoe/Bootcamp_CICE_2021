//
//  Created on ___DATE___.
// ___VARIABLE_name___.swift - Very brief description
//

import Foundation
import SwiftUI

final class ___VARIABLE_name___Coordinator: BaseCoordinator {
    
    typealias ContentView = ___VARIABLE_name___View
    typealias ViewModel = ___VARIABLE_name___ViewModel
    typealias Interactor = ___VARIABLE_name___Interactor
    typealias Provider = ___VARIABLE_name___Provider
    
    static func navigation(dto: ___VARIABLE_name___CoordinatorDTO? = nil) -> NavigationView<ContentView> {
        NavigationView {
            self.view()
        }
    }
    
    static func view(dto: ___VARIABLE_name___CoordinatorDTO? = nil) -> ContentView {
        let vip = BaseCoordinator.coordinator(viewModel: ViewModel.self,
                                              interactor: Interactor.self,
                                              provider: Provider.self)
        let view = ContentView(viewModel: vip.viewModel)
        return view
    }
}

struct ___VARIABLE_name___CoordinatorDTO {
    
}

