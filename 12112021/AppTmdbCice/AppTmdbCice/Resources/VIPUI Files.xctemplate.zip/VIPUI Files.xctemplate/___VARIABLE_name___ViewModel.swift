//
//  Created on ___DATE___.
// ___VARIABLE_name___.swift - Very brief description
//


import Foundation

// Mark: - Output -> Interactor
protocol ___VARIABLE_name___InteractorOutputProtocol: BaseInteractorOutputProtocol {
    
}

final class ___VARIABLE_name___ViewModel: BaseViewModel, ObservableObject {

    // MARK: VIP Dependencies
    var interactor: ___VARIABLE_name___InteractorInputProtocol? {
        super.baseInteractor as? ___VARIABLE_name___InteractorInputProtocol
    }
    
}

// Mark: - extension Output ->  Interactor
extension ___VARIABLE_name___ViewModel: ___VARIABLE_name___InteractorOutputProtocol {

}
