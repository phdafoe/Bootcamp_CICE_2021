//
//  Created on ___DATE___.
// ___VARIABLE_name___.swift - Very brief description
//

import Foundation

// Mark: - Input Interactor
protocol ___VARIABLE_name___InteractorInputProtocol: BaseInteractorInputProtocol {
    
}

// Mark: - Output -> Provider
protocol ___VARIABLE_name___ProviderOutputProtocol: BaseProviderOutputProtocol {
    
}

final class ___VARIABLE_name___Interactor: BaseInteractor {

    // MARK: VIP Dependencies
    weak var viewModel: ___VARIABLE_name___InteractorOutputProtocol? {
        super.baseViewModel as? ___VARIABLE_name___InteractorOutputProtocol
    }
    var provider: ___VARIABLE_name___ProviderInputProtocol? {
        super.baseProvider as? ___VARIABLE_name___ProviderInputProtocol
    }

}

// Mark: - extension -> Input Interactor
extension ___VARIABLE_name___Interactor: ___VARIABLE_name___InteractorInputProtocol {

}

// Mark: - extension Output -> Provider
extension ___VARIABLE_name___Interactor: ___VARIABLE_name___ProviderOutputProtocol{
    
}
